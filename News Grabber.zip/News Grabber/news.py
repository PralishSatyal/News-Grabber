"""
    (C) Pralish Satyal 2023

    News Grabber with RSS Feeds for easier view of News Sources

    www.pralish.com
    pralishbusiness@gmail.com
    26/12/2023
"""
import tkinter as tk
from tkinter import messagebox, ttk
import feedparser
import webbrowser
import time

def get_news():
    try:
        # Parse the RSS feed from BBC News
        feed = feedparser.parse('http://feeds.bbci.co.uk/news/rss.xml')

        # Check if the feed was parsed successfully
        if 'entries' in feed:
            articles = feed.entries

            # Create a new window to display the news
            news_window = tk.Toplevel()
            news_window.title('News')
            news_window.configure(bg='#252525')
            news_window.geometry('720x480')

            def show_details(event):
                # Get the selected index and retrieve the corresponding article
                index = listbox.curselection()
                if index:
                    article = articles[index[0]]

                    # Create a new window to show the article details
                    article_window = tk.Toplevel(news_window)
                    article_window.title(article.title)
                    article_window.configure(bg='#252525')

                    # Display the article details
                    details_label = tk.Label(article_window, text=article.description, font=('Helvetica', 12), wraplength=500, padx=20, pady=20, fg='white', bg='#252525')
                    details_label.pack()

                    # Display the article link
                    link_label = tk.Label(article_window, text=article.link, font=('Helvetica', 10), fg='yellow', bg='#252525', cursor='hand2')
                    link_label.pack(pady=10)

                    # Open the article link when clicked
                    def open_link(event):
                        webbrowser.open(article.link)
                    link_label.bind('<Button-1>', open_link)

            # Create a listbox to show the news articles
            listbox = tk.Listbox(news_window, font=('Helvetica', 12), selectbackground='#404040', selectforeground='white', bd=0, bg='#252525', fg='white', highlightthickness=0)
            listbox.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

            # Add the news articles to the listbox with newline space
            for article in articles:
                headline = article.title.replace('-', '-\n')
                listbox.insert(tk.END, headline + '\n')

            # Bind the click event to show the article details
            listbox.bind('<<ListboxSelect>>', show_details)

            # Configure the listbox to allow vertical scrolling
            scrollbar = tk.Scrollbar(news_window)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            listbox.config(yscrollcommand=scrollbar.set)
            scrollbar.config(command=listbox.yview)


        else:
            messagebox.showerror('Error', 'Failed to fetch news. Please try again later.')

    except:
        messagebox.showerror('Error', 'Failed to connect to the news server.')


# Create the main window
window = tk.Tk()
window.title('RSS News App')
window.geometry('500x400')
window.configure(bg='#252525')

# Style the window
style = ttk.Style()
style.configure('TButton', font=('Helvetica', 12), padding=10, background='#404040')
style.configure('TLabel', font=('Helvetica', 14), padding=10, background='#252525', foreground='white')

# Create a label for the current date and time
time_label = ttk.Label(window, font=('Helvetica', 12), background='#252525', foreground='white')
time_label.pack(pady=20)

# Function to update the time label
def update_time():
    current_time = time.strftime('%H:%M:%S')
    current_date = time.strftime('%Y-%m-%d')
    time_label.config(text=f'Date: {current_date}\nTime: {current_time}')
    window.after(1000, update_time)

# Update the time label initially
update_time()

# Create a label
label = ttk.Label(window, text='Click the button to get news:', style='TLabel')
label.pack(pady=20)

# Create a button to fetch news
button = ttk.Button(window, text='Get News', command=get_news, style='TButton')
button.pack()

# Set the foreground color of the button using style.map
style.map('TButton', foreground=[('pressed', 'black'), ('active', 'black')])

# Make the window resizable
window.resizable(True, True)

# Run the main event loop
window.mainloop()

